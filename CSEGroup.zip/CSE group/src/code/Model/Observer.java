package code.Model;

public interface Observer {
	public void update();

}
