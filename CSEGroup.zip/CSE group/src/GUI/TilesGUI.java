package GUI;

import javax.swing.JPanel;

public class TilesGUI {
	JPanel tile = new JPanel();
	
	
	

}
